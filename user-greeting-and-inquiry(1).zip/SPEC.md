# خير - لإدارة يومك (Khayr - Day Management)

## Concept & Vision

**خَيْر** هو نظام إدارة يومية شامل يجمع بين البساطة والعمق. يشعرك وكأنك ترسم خريطة لحياتك - كل ركن يمثل جانباً من جوانب الإنسان المتكامل. التطبيق يجمع بين الروحانية والعملية، يساعدك على أن تكون نسخة أفضل من نفسك يومياً.

الشعور: هدوء، تركيز، إلهام، تطور مستمر، نقاء.

## Design Language - Clean White Theme

### Color Palette (White Theme)
- **Background Primary**: `#FFFFFF` (أبيض نقي)
- **Background Secondary**: `#F8F9FA` (رمادي فاتح جداً)
- **Background Card**: `#FFFFFF` (أبيض)
- **Primary**: `#1B4D3E` (أخضر داكن لكلمة "خير")
- **Secondary**: `#C9A227` (ذهبي)
- **Text Primary**: `#1A1A1A` (أسود)
- **Text Secondary**: `#6B7280` (رمادي)
- **Border**: `#E5E7EB`
- **Success**: `#10B981`
- **Danger**: `#EF4444`
- **Friday Accent**: `#FEF3C7` (أصفر دافئ ليوم الجمعة)

### Eight Pillars
1. 💚 الروح (Spirit) - الجانب الروحاني
2. 💼 المهنة (Career) - العمل والمسيرة
3. 🧠 العقل (Mind) - التعلم والثقافة
4. 💪 الجسد (Body) - الصحة والرياضة
5. 🤝 الاجتماعي (Social) - العلاقات
6. 👨‍👩‍👧 العائلة (Family) - الأسرة
7. 💰 المال (Finance) - المال والاستثمار
8. 🌱 التطور (Growth) - التطوير الذاتي

### Inspirational Quotes
أقوال من علماء ومفكرين مؤثرين:
- "لا تستسلم، فالبداية دائماً هي الأصعب" - أحمد الشقيري
- "العلم أساس كل نجاح" - ابن خلدون
- "من طلب العلا سهر الليالي" - علي بن أبي طالب
- "التفكير الإيجابي يفتح كل الأبواب" - ويل شورت
- "النجاح يحتاج إلى挣扎 ولا ليس حظ" - كولونيل ساندرز
- "اقرأ ثلاثين كتاباً في سنتك ستتغير حياتك" - وارن بافيت

## Technical
- Single HTML file
- localStorage for persistence
- Vanilla JavaScript
- White theme with green accent for "Khayr"